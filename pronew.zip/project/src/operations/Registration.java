package operations;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DB.DbLyer;
import DBO.Data;


@WebServlet("/Registration")
public class Registration extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{

		doPost(request, response);		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		 String fname=request.getParameter("fname");
		 String mname=request.getParameter("mname");
		 String lname=request.getParameter("lname");
		 String gender=request.getParameter("gender");
		 String dob=request.getParameter("dob");
		 String nationality=request.getParameter("nationality");
		 String address=request.getParameter("address");
		 String state=request.getParameter("state");
		 String city=request.getParameter("city");
		 int pincode=Integer.parseInt(request.getParameter("pincode"));
		 
		  double mobile=Double.parseDouble(request.getParameter("mobile"));
		 String email=request.getParameter("email");
		 double adharcard=Double.parseDouble(request.getParameter("adharcard"));
		 String pan=request.getParameter("pan");
		 String org=request.getParameter("org");
		 String dsc=request.getParameter("dsc");
		 
		 String password=request.getParameter("password");
		 System.out.println("password chekc"+password);
	//	 String status=request.getParameter("status");
		 String photo=request.getParameter("photo");
		 String signature=request.getParameter("signature");
		 
		 
		 Data d= new Data();//dbo.data object creatio;
		 d.setFname(fname);
		 d.setMname(mname);
		 d.setLname(lname);
		 d.setGender(gender);
		 d.setDob(dob);		 d.setNationality(nationality);
		 d.setAddress(address);
		 d.setState(state);
		 d.setCity(city);
		 d.setPincode(pincode);
		 d.setMobile(mobile);
		 d.setEmail(email);
		 d.setAdharcard(adharcard);
		 d.setPan(pan);
		 d.setOrg(org);
		 d.setDsc(dsc);		 
		 d.setPassword(password);
		 d.setPhoto(photo);
		 d.setSignature(signature);
		 
		 
		 if(d.getPassword() != null)
		 {
			System.out.println(d.getPassword());
			 DbLyer dbl= new DbLyer();
			 dbl.genratdid(d); 
			 
//			 
//			 HttpSession session=request.getSession();  
//		        session.setAttribute("d",d); 
//		        
//		     RequestDispatcher rs= request.getRequestDispatcher("/JsonWrite");  
//		     rs.forward(request, response);
			 
			 
			 int id=d.getApplication_id();
			 System.out.println("id is sss"+id);
			 request.setAttribute("AppId", id);
			 
			 RequestDispatcher rs= request.getRequestDispatcher("display.jsp");  
			 rs.forward(request, response);
		 }
		
	        
	        
		 
		 
		 
		 // data object set in session
		 
		
		 
	}

}