package DB;


import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.xml.ws.Response;

import org.omg.CORBA.Request;

import DBO.Data;

public class DbLyer {
	
	
	final static String url="jdbc:mysql://localhost/DSC";
	final static String user="root";
	final static String pwd="";
		
	Data data= new Data();
	
	static Connection getConnection() throws Exception
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con =DriverManager.getConnection(url,user,pwd);
		return con;
	}

	public void insertdata(Data d) {
		// TODO Auto-generated method stub
		
		
		
		
		String query="insert into user_info(fname,mname,lname,gender,dob,nationality,state,city,address,pincode,mobile,email,pan,adharcard,org,application_id) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		try {
			
			

			Connection con =getConnection();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, d.getFname());
			ps.setString(2, d.getMname());
			ps.setString(3, d.getLname());
			ps.setString(4, d.getGender());
			ps.setString(5,  d.getDob());
			ps.setString(6, d.getNationality());
			ps.setString(7, d.getState());
			ps.setString(8, d.getCity());
			ps.setString(9, d.getAddress());
			ps.setInt(10, d.getPincode());
			
			ps.setDouble(11, d.getMobile());
			ps.setString(12, d.getEmail());
			ps.setString(13, d.getPan());
			ps.setDouble(14, d.getAdharcard());
			ps.setString(15, d.getOrg());
			ps.setInt(16, d.getApplication_id());
			
			
			int RowsAffected=ps.executeUpdate();
			if(RowsAffected!=1)
			{
			System.out.println("data  NOt inserted");
			}
			else
			{
				System.out.println("data inserted");
			}
			
			
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
			
		
		
	}

	public void genratdid(Data d)
	{
		// TODO Auto-generated method stub
		
		try {
			
			String query="insert into user_login(password) values(?)";
			Connection con =getConnection();
			PreparedStatement ps = con.prepareStatement(query);
			System.out.println("check me"+d.getPassword());
			ps.setString(1, d.getPassword());
			
			int RowsAffected=ps.executeUpdate();
			if(RowsAffected!=1)
			{
			System.out.println("password not inserted");
			}
			
			else
			{
			
				System.out.println("comee hear..");
				String query1="select application_id from user_login ORDER BY application_id DESC LIMIT 1";
				//String query2="select last_insert_id() from user_login";
				System.out.println("comee hear..");
				Statement st1=con.createStatement();
				//PreparedStatement st=con.prepareStatement(query1);
				System.out.println("comee hear..");
				ResultSet rs=st1.executeQuery(query1);
				int application_id=0;
				//WriteJson obj=new WriteJson();
				while(rs.next())
				{
					System.out.println("hhhhhh"+rs.getInt("application_id"));
					application_id=+rs.getInt("application_id");
					d.setApplication_id(application_id);
					WriteJson.jsonData(d);
					
					
				}
				
				insertdata(d);
				insertDocument(d);
				
			}
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		
		
	}

	private void insertDocument(Data d) {
		// TODO Auto-generated method stub
		FileInputStream fis1=null;
		FileInputStream fis2=null;
		
		String query3="insert into user_documents(application_id,photo,signature) values(?,?,?)";
		
		try {
			
			String myloc1=d.getPhoto();
			File image1= new File(myloc1);//for photo
			
			String myloc2=d.getPhoto();
			File image2= new File(myloc2);//for signature
			
			
			Connection con =getConnection();
			PreparedStatement ps = con.prepareStatement(query3);
			ps.setInt(1, d.getApplication_id());
			ps.setBinaryStream(2, (InputStream) fis1, (int) (image1.length()));
			ps.setBinaryStream(3, (InputStream) fis2, (int) (image2.length()));
			
			int RowsAffected=ps.executeUpdate();
			if(RowsAffected!=1)
			{
			System.out.println("document not inserted");
			}
			else
			{
				System.out.println("document  inserted");
				
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		

		
		
		
	}
	
	

}
