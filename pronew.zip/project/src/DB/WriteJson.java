package DB;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import DBO.Data;

public class WriteJson 
{
	 @SuppressWarnings("unchecked")
	 public static void jsonData(Data d)
	 {
		// public static void main(String args[])
	// {
			//First Employee
		    	JSONObject loginDetails = new JSONObject();
		    	String application_id= Integer.toString(d.getApplication_id());
		    	System.out.println(application_id);
		    	
		    	String password=d.getPassword();
		    	System.out.println(password);
		    	loginDetails.put("application_id", application_id);
		    	
		    	loginDetails.put("password",password);
		    	
		    	
		    	
		    	JSONObject loginObject = new JSONObject(); 
		    	loginObject.put("login", loginDetails);
		    	
		    	JSONArray userList = new JSONArray();
		    	userList.add(loginObject);
		    	
		    	//Add employees to list
		/*
		 * JSONArray employeeList = new JSONArray(); employeeList.add(employeeObject);
		 */
		    	System.out.println("check me heare ...2");
		    	//Write JSON file
		    	try (FileWriter file = new FileWriter("F:/ProjectEclipse/project//WebContent/login.json",true))
		    	{
		    		System.out.println("check me heare 3...");
		            file.write(userList.toJSONString());
		            file.flush();

		        } catch (IOException e) 
		    	{
		            e.printStackTrace();
		        }

		// }
	    		 }

}
